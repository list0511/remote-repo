package com.kardia.volunteersystem.io.netty;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class NettyConfig {
    @Bean(initMethod = "start", destroyMethod = "stop")
    public WebSocketChatServer webSocketChatServer() {
        return new WebSocketChatServer();
    }
}