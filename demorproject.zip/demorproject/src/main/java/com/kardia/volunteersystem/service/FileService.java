package com.kardia.volunteersystem.service;

import com.kardia.volunteersystem.dao.entity.FileEntity;
import org.springframework.stereotype.Service;

import java.io.File;

@Service
public class FileService {
    public File getTheFile(String path){
        return new File(path);
    }

}
