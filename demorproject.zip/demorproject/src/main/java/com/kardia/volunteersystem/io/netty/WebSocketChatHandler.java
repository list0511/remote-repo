package com.kardia.volunteersystem.io.netty;

import com.google.gson.Gson;
import com.kardia.volunteersystem.dao.entity.MessageEntity;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.handler.codec.http.websocketx.BinaryWebSocketFrame;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import io.netty.util.concurrent.GlobalEventExecutor;
import jakarta.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class WebSocketChatHandler extends SimpleChannelInboundHandler<Object> {
    private static ChannelGroup channels = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);
    private static Map<Channel, String> userMap = new ConcurrentHashMap<>();
//    private static Logger logger = LoggerFactory.getLogger(WebSocketChatHandler.class);



    @Override
    protected void channelRead0(ChannelHandlerContext ctx, Object msg) throws Exception {
        System.out.println("userMap" + userMap.size());
        System.out.println("channels" + channels);
        System.out.println(msg);
        Gson gson = new Gson();
        MessageEntity message = gson.fromJson((String) msg, MessageEntity.class);
        Channel sender = ctx.channel();

        // Check if the userMap already has a username associated with this channel
        String username = userMap.get(sender);

        if (username == null) {
            // If there's no username associated with this channel, assume the first message is the username
            username = message.getUserSend();
            userMap.put(sender, username);
        } else {
            // Check if it's a private message
            String recipientName = message.getUserReceive();
            Channel recipient = findChannelByString(userMap, recipientName);
            if (recipient == null) {
                message.setText("该用户不存在或已离线");
                message.setType(1);
                message.setUserReceive(username);
                sender.writeAndFlush(gson.toJson(message)).addListener((ChannelFutureListener) future -> {
                    if (!future.isSuccess()) {
                        System.out.println("send msg to " + message.getUserReceive() + " failed");
                    }
                });
            }
            if (recipient != null) {
                recipient.writeAndFlush(gson.toJson(message)).addListener((ChannelFutureListener) future -> {
                    if (!future.isSuccess()) {
                        System.out.println("send msg to " + message.getUserReceive() + " failed");
                    }
//                    else {
//                        // 如果消息成功发送，则异步进行数据库存储
//                        CompletableFuture.runAsync(() -> {
//                            // 调用MessageService的NewTheMessage方法
//                            int result = messageService.NewTheMessage(message);
//                            if(result==-1)
//                            {
//
//                             }
//                        }).exceptionally(ex -> {
//                            // 异常处理
//                            ex.printStackTrace();
//                            return null;
//                        });
//                    }
                });
            }
        }
    }

    @Override
    public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
        System.out.println("sadasd");
        channels.add(ctx.channel());
    }

    @Override
    public void handlerRemoved(ChannelHandlerContext ctx) throws Exception {
        channels.remove(ctx);
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        cause.printStackTrace();
        ctx.close();
    }

    public Channel findChannelByString(Map<Channel, String> channelMap, String targetString) {
        for (Map.Entry<Channel, String> entry : channelMap.entrySet()) {
            if (entry.getValue().equals(targetString)) {
                return entry.getKey(); // 返回找到的 Channel
            }
        }
        return null; // 如果未找到匹配的 String，返回 null 或者抛出异常
    }

    public void delMap(Channel channel){
        userMap.remove(channel);
    }


}
