package com.kardia.volunteersystem.utils;

import com.google.gson.JsonArray;

public interface SystemConstants {
    JsonArray sysConstants = new JsonArray();
}
